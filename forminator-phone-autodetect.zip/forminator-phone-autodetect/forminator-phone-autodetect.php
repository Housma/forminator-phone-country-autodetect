<?php
/*
Plugin Name: Forminator Phone Country Autodetect
Description: Automatically sets country calling code in Forminator phone field based on user IP. Requires Forminator and international mode enabled on phone field.
Version: 1.0
Author: Huseyin Mardinli
Donate link: https://www.paypal.com/donate/?hosted_button_id=MDDGA8HUZA4B4
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html
*/

if (!defined('ABSPATH')) exit;

// Include admin settings
require_once plugin_dir_path(__FILE__) . 'includes/settings-page.php';

// Hook into Forminator's phone field rendering
add_filter('forminator_field_phone_markup', 'fpca_modify_phone_field', 10, 5);

function fpca_modify_phone_field($html, $id, $required, $placeholder, $value) {
	$user_ip = Forminator_Geo::get_user_ip();
	$country_code = fpca_get_country_code($user_ip);

	if ($country_code) {
		$html = str_replace('value=""', "value=$country_code", $html);
	}
	return $html;
}

// Fetch country calling code using ipapi
function fpca_get_country_code($user_ip) {
	$api_key = get_option('fpca_api_key', '');
	$url = 'https://ipapi.co/' . $user_ip . '/country_calling_code/';
	if (!empty($api_key)) {
		$url .= '?key=' . urlencode($api_key);
	}

	$response = wp_remote_get($url, ['timeout' => 5]);
	if (is_wp_error($response)) return false;

	return trim(wp_remote_retrieve_body($response));
}
