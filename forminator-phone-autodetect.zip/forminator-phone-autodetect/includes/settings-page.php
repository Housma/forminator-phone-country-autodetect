<?php
// Add settings menu under "Settings"
add_action('admin_menu', function () {
	add_options_page(
		'Forminator Phone Autodetect',
		'Forminator Phone Autodetect',
		'manage_options',
		'fpca-settings',
		'fpca_render_settings_page'
	);
});

// Register plugin setting with sanitization
add_action('admin_init', function () {
	register_setting('fpca_settings_group', 'fpca_api_key', 'sanitize_text_field');
});

// Render admin settings UI
function fpca_render_settings_page() {
	?>
	<div class="wrap">
		<h1>Forminator Phone Country Autodetect</h1>
		
		<div style="border:1px solid #f00; background:#fff3f3; padding:15px; margin-bottom:20px;">
			<strong>Important:</strong> This plugin requires the <a href="https://wordpress.org/plugins/forminator/" target="_blank">Forminator</a> plugin.<br>
			Make sure that:
			<ul style="margin-left:20px;">
				<li>The phone field uses <strong>International format</strong></li>
				<li>Forminator is active</li>
			</ul>
		</div>

		<form method="post" action="options.php">
			<?php settings_fields('fpca_settings_group'); ?>
			<?php do_settings_sections('fpca_settings_group'); ?>

			<table class="form-table">
				<tr valign="top">
					<th scope="row">ipapi.co API Key (optional)</th>
					<td>
						<input type="text" name="fpca_api_key" value="<?php echo esc_attr(get_option('fpca_api_key')); ?>" size="40" />
						<p class="description">
							Leave this blank to use the free quota (~1000 requests/month).<br>
							Get a free or paid key at <a href="https://ipapi.co" target="_blank">ipapi.co</a>.
						</p>
					</td>
				</tr>
			</table>

			<?php submit_button(); ?>
		</form>
	</div>
	<?php
}
