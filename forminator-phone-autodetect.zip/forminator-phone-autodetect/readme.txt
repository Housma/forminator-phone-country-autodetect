=== Forminator Phone Country Autodetect ===
Contributors: housma
Donate link: https://www.paypal.com/donate/?hosted_button_id=MDDGA8HUZA4B4
Tags: forminator, phone field, ip geolocation, country code, auto country, ipapi
Requires at least: 5.0
Tested up to: 6.8
Requires PHP: 7.2
Stable tag: 1.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Automatically detects the user's country and pre-fills Forminator's phone field with the correct international calling code. Uses ipapi.co with optional API key support.

== Description ==

This lightweight plugin automatically sets the correct country calling code (`+44`, `+49`, etc.) in **Forminator's phone field** based on the user's IP address. No manual selection needed — just install, activate, and go!

Perfect for improving user experience and reducing friction on international forms.

**Features:**

- Detects user IP via Forminator's built-in methods
- Calls [ipapi.co](https://ipapi.co) to determine the country calling code
- Supports optional API key (free and paid)
- Adds an admin settings page to manage the key
- Built and maintained by [Huseyin Mardinli](https://github.com/Housma)

== Installation ==

1. Upload the plugin folder to `/wp-content/plugins/` or install via WordPress Admin > Plugins > Add New.
2. Activate the plugin.
3. Go to **Settings > Forminator Phone Autodetect**.
4. (Optional) Enter your ipapi.co API key to avoid quota limits.

== Usage ==

Make sure:
- You're using the **Forminator** plugin by WPMU DEV.
- Your phone field is configured with **International Format**.
- You do **not** set a default value for the phone field.

Once active, the phone field will automatically be pre-filled with the appropriate international calling code based on the user's IP.

== Screenshots ==

1. Plugin settings page with API key field and setup warnings.
2. Forminator phone field pre-filled with country code.

== Frequently Asked Questions ==

= Do I need an API key? =
No, but it's recommended. Without a key, you’re limited to around 1000 IP lookups per month. You can get a free key from [ipapi.co](https://ipapi.co).

= Does it work with AJAX forms or popups? =
Yes, as long as Forminator renders the field server-side. Dynamic/AJAX-injected forms may require custom adjustments.

= What if the location isn't detected? =
The field will simply remain empty or use the Forminator default.

== Changelog ==

= 1.0 =
* Initial release with country detection and settings page

== Upgrade Notice ==

= 1.0 =
Initial release.

== Author ==

Developed by Huseyin Mardinli  
GitHub: https://github.com/Housma  
💙 Donate: [https://www.paypal.com/donate/?hosted_button_id=MDDGA8HUZA4B4](https://www.paypal.com/donate/?hosted_button_id=MDDGA8HUZA4B4)
